#!/usr/bin/env python3
"""
Quill Runtime Performance Benchmarking Script - Environment Variable Version
Passes workers as: QUILL_WORKERS=3 ./a.out 12
"""

import subprocess
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import time
import os
import re
import json
from dataclasses import dataclass
from typing import List, Dict, Tuple
import argparse
from datetime import datetime
import sys

# ===================== CONFIGURATION =====================
@dataclass
class Config:
    """Configuration for benchmarking"""
    # Range of workers to test (passed as environment variable)
    WORKERS_RANGE: Tuple[int, int] = (1, 5)
    
    # Number of runs per worker count
    RUNS_PER_WORKER: int = 10
    
    # N-Queens board size
    BOARD_SIZE: int = 12
    
    # Compilation and execution settings
    COMPILE_CMD: str = "g++ ./tests/nqueens.cpp ./src/quill-runtime.cpp -std=c++23 -pthread -O2 -I./include -o ./bin/solution"
    EXECUTABLE: str = "./bin/solution"
    
    # Output settings
    OUTPUT_DIR: str = "benchmark_results"
    PLOT_FORMAT: str = "png"
    VERBOSE: bool = False
    PRINT_COMMANDS: bool = True

# ===================== UTILITY FUNCTIONS =====================
def compile_program() -> bool:
    """Compile the program once (workers are environment variable)"""
    if Config.PRINT_COMMANDS:
        print(f"  ⚡ Executing: {Config.COMPILE_CMD}")
    
    try:
        result = subprocess.run(
            Config.COMPILE_CMD.split(),
            capture_output=True,
            text=True,
            timeout=30
        )
        if result.returncode != 0:
            print(f"Compilation failed:\n{result.stderr}")
            return False
        return True
    except subprocess.TimeoutExpired:
        print("Compilation timeout!")
        return False
    except Exception as e:
        print(f"Compilation error: {e}")
        return False

def run_single_execution(workers: int, run_number: int) -> Tuple[float, bool]:
    """Run the program once with specified workers as environment variable"""
    try:
        # Command: QUILL_WORKERS=3 ./a.out 12
        cmd = f"QUILL_WORKERS={workers} {Config.EXECUTABLE} {Config.BOARD_SIZE}"
        
        if Config.PRINT_COMMANDS:
            print(f"  ⚡ Run {run_number}: {cmd}")
        
        start_time = time.time()
        
        # Execute with environment variable in the command string
        result = subprocess.run(
            cmd,
            shell=True,  # IMPORTANT: shell=True to interpret environment variable
            capture_output=True,
            text=True,
            timeout=120  # 2 minute timeout
        )
        
        execution_time = time.time() - start_time
        
        if result.returncode != 0:
            print(f"Execution failed (exit code {result.returncode})")
            if Config.VERBOSE:
                print(f"STDOUT:\n{result.stdout}")
                print(f"STDERR:\n{result.stderr}")
            return 0.0, False
        
        # Try to extract time from program output
        time_pattern = r'Time\s*=\s*([\d.]+)sec'
        match = re.search(time_pattern, result.stdout)
        if match:
            program_time = float(match.group(1))
        else:
            program_time = execution_time
        
        # Check if solution is correct
        if "OK" in result.stdout:
            return program_time, True
        else:
            print("Incorrect solution!")
            return program_time, False
            
    except subprocess.TimeoutExpired:
        print("Execution timeout!")
        return 0.0, False
    except Exception as e:
        print(f"Execution error: {e}")
        return 0.0, False

def calculate_statistics(times: List[float]) -> Dict:
    """Calculate statistical measures for execution times"""
    if not times:
        return {}
    
    arr = np.array(times)
    
    return {
        'mean': np.mean(arr),
        'median': np.median(arr),
        'std': np.std(arr),
        'min': np.min(arr),
        'max': np.max(arr),
        'q1': np.percentile(arr, 25),
        'q3': np.percentile(arr, 75),
        'iqr': np.percentile(arr, 75) - np.percentile(arr, 25),
        'cv': (np.std(arr) / np.mean(arr)) * 100 if np.mean(arr) > 0 else 0,
        'count': len(arr)
    }

# ===================== BENCHMARKING FUNCTION =====================
def run_benchmark(config: Config) -> Dict[int, Dict]:
    """Main benchmarking function - workers as environment variable"""
    
    results = {}
    
    # Create output directory
    os.makedirs(config.OUTPUT_DIR, exist_ok=True)
    
    print(f"Benchmarking with board size {config.BOARD_SIZE}")
    print(f"Workers range: {config.WORKERS_RANGE[0]}-{config.WORKERS_RANGE[1]}")
    print(f"Runs per worker: {config.RUNS_PER_WORKER}")
    print(f"Command format: QUILL_WORKERS=X ./a.out {config.BOARD_SIZE}")
    print("=" * 60)
    
    # Compile once
    print(f"\nStep 1: Compiling program once...")
    if not compile_program():
        print("Compilation failed! Exiting.")
        return results
    
    # Verify executable exists
    if not os.path.exists(config.EXECUTABLE):
        print(f"Error: Executable {config.EXECUTABLE} not found after compilation!")
        return results
    
    for workers in range(config.WORKERS_RANGE[0], config.WORKERS_RANGE[1] + 1):
        print(f"\n{'='*60}")
        print(f"Testing with QUILL_WORKERS = {workers}")
        print('='*60)
        
        # Test the command first
        print(f"\nTesting command...")
        test_cmd = f"QUILL_WORKERS={workers} {config.EXECUTABLE} {config.BOARD_SIZE}"
        print(f"  Test command: {test_cmd}")
        
        # Quick test to ensure it works
        test_result = subprocess.run(
            test_cmd,
            shell=True,
            capture_output=True,
            text=True,
            timeout=10
        )
        
        if test_result.returncode != 0:
            print(f"  ❌ Test failed! Exit code: {test_result.returncode}")
            if config.VERBOSE:
                print(f"  Error output: {test_result.stderr[:200]}")
            continue
        
        # Run multiple executions with this worker count
        print(f"\nRunning {config.RUNS_PER_WORKER} executions...")
        execution_times = []
        successes = 0
        
        for run in range(config.RUNS_PER_WORKER):
            print(f"  Run {run+1}/{config.RUNS_PER_WORKER}: ", end="", flush=True)
            
            exec_time, success = run_single_execution(workers, run+1)
            
            if success:
                execution_times.append(exec_time)
                successes += 1
                print(f"{exec_time:.4f}s ✓")
            else:
                print(f"Failed ✗")
            
            # Small delay to avoid system overload
            time.sleep(0.1)
        
        # Calculate statistics
        print(f"\nCalculating statistics...")
        if execution_times:
            stats = calculate_statistics(execution_times)
            stats['success_rate'] = (successes / config.RUNS_PER_WORKER) * 100
            
            results[workers] = {
                'times': execution_times,
                'stats': stats
            }
            
            print(f"  Success rate: {stats['success_rate']:.1f}%")
            print(f"  Mean time: {stats['mean']:.4f}s")
            print(f"  Std dev: {stats['std']:.4f}s")
            print(f"  Min/Max: {stats['min']:.4f}s / {stats['max']:.4f}s")
            
            # Also print individual times if verbose
            if config.VERBOSE and execution_times:
                print(f"  Individual times: {[f'{t:.3f}' for t in execution_times]}")
        else:
            print(f"  No successful runs for QUILL_WORKERS={workers}")
    
    return results

# ===================== VISUALIZATION FUNCTIONS =====================
def create_performance_plot(results: Dict[int, Dict], config: Config) -> str:
    """Create bar chart for performance vs worker count"""
    if not results:
        return ""
    
    workers_list = sorted(results.keys())
    means = [results[w]['stats']['mean'] for w in workers_list]
    stds = [results[w]['stats']['std'] for w in workers_list]
    
    fig, ax = plt.subplots(figsize=(10, 6))
    bars = ax.bar(range(len(workers_list)), means, 
                  yerr=stds, capsize=5, alpha=0.7, color='skyblue')
    ax.set_xlabel('QUILL_WORKERS (Environment Variable)', fontsize=12)
    ax.set_ylabel('Execution Time (seconds)', fontsize=12)
    ax.set_title(f'N-Queens ({config.BOARD_SIZE}) - Performance vs Worker Count', 
                 fontsize=14, fontweight='bold')
    ax.set_xticks(range(len(workers_list)))
    ax.set_xticklabels(workers_list)
    ax.grid(True, alpha=0.3, axis='y')
    
    # Add value labels on bars
    for bar, mean, std in zip(bars, means, stds):
        height = bar.get_height()
        ax.text(bar.get_x() + bar.get_width()/2., height + std + 0.01,
                f'{mean:.3f}±{std:.3f}s', ha='center', va='bottom', fontsize=10)
    
    plt.tight_layout()
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{config.OUTPUT_DIR}/performance_plot_{timestamp}.{config.PLOT_FORMAT}"
    plt.savefig(filename, dpi=300, bbox_inches='tight')
    plt.close()
    
    return filename

def create_speedup_plot(results: Dict[int, Dict], config: Config) -> str:
    """Create speedup analysis plot"""
    if not results or 1 not in results:
        return ""
    
    workers_list = sorted(results.keys())
    means = [results[w]['stats']['mean'] for w in workers_list]
    baseline = results[1]['stats']['mean']
    speedups = [baseline / m for m in means]
    ideal = workers_list  # Ideal linear speedup
    
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.plot(workers_list, speedups, 'o-', linewidth=2, markersize=8, 
            label='Measured Speedup', color='green')
    ax.plot(workers_list, ideal, '--', linewidth=1.5, alpha=0.7,
            label='Ideal Linear Speedup', color='red')
    ax.set_xlabel('QUILL_WORKERS', fontsize=12)
    ax.set_ylabel('Speedup (relative to 1 worker)', fontsize=12)
    ax.set_title('Speedup Analysis', fontsize=14, fontweight='bold')
    ax.legend()
    ax.grid(True, alpha=0.3)
    
    # Add speedup values
    for w, s in zip(workers_list, speedups):
        ax.text(w, s + 0.05, f'{s:.2f}x', ha='center', fontsize=10)
    
    plt.tight_layout()
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{config.OUTPUT_DIR}/speedup_plot_{timestamp}.{config.PLOT_FORMAT}"
    plt.savefig(filename, dpi=300, bbox_inches='tight')
    plt.close()
    
    return filename

def create_distribution_plot(results: Dict[int, Dict], config: Config) -> str:
    """Create box plot for execution times distribution"""
    if not results:
        return ""
    
    workers_list = sorted(results.keys())
    boxplot_data = [results[w]['times'] for w in workers_list]
    
    fig, ax = plt.subplots(figsize=(10, 6))
    bp = ax.boxplot(boxplot_data, labels=workers_list, patch_artist=True)
    
    # Color the boxes
    colors = plt.cm.Pastel1(np.linspace(0, 1, len(workers_list)))
    for patch, color in zip(bp['boxes'], colors):
        patch.set_facecolor(color)
    
    ax.set_xlabel('QUILL_WORKERS', fontsize=12)
    ax.set_ylabel('Execution Time (seconds)', fontsize=12)
    ax.set_title('Distribution of Execution Times', fontsize=14, fontweight='bold')
    ax.grid(True, alpha=0.3, axis='y')
    
    plt.tight_layout()
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{config.OUTPUT_DIR}/distribution_plot_{timestamp}.{config.PLOT_FORMAT}"
    plt.savefig(filename, dpi=300, bbox_inches='tight')
    plt.close()
    
    return filename

def create_efficiency_plot(results: Dict[int, Dict], config: Config) -> str:
    """Create parallel efficiency plot"""
    if not results or 1 not in results:
        return ""
    
    workers_list = sorted(results.keys())
    means = [results[w]['stats']['mean'] for w in workers_list]
    baseline = results[1]['stats']['mean']
    speedups = [baseline / m for m in means]
    efficiencies = [s / w for s, w in zip(speedups, workers_list)]
    
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.plot(workers_list, efficiencies, 's-', linewidth=2, markersize=8, color='purple')
    ax.axhline(y=1.0, color='r', linestyle='--', alpha=0.5, label='Perfect Efficiency')
    ax.set_xlabel('QUILL_WORKERS', fontsize=12)
    ax.set_ylabel('Efficiency (speedup/workers)', fontsize=12)
    ax.set_title('Parallel Efficiency', fontsize=14, fontweight='bold')
    ax.legend()
    ax.grid(True, alpha=0.3)
    
    # Add efficiency values
    for w, e in zip(workers_list, efficiencies):
        ax.text(w, e + 0.02, f'{e:.2f}', ha='center', fontsize=10)
    
    plt.tight_layout()
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{config.OUTPUT_DIR}/efficiency_plot_{timestamp}.{config.PLOT_FORMAT}"
    plt.savefig(filename, dpi=300, bbox_inches='tight')
    plt.close()
    
    return filename

def create_simple_bar_chart(results: Dict[int, Dict], config: Config) -> str:
    """Create a simple bar chart"""
    if not results:
        return ""
    
    workers_list = sorted(results.keys())
    means = [results[w]['stats']['mean'] for w in workers_list]
    stds = [results[w]['stats']['std'] for w in workers_list]
    
    fig, ax = plt.subplots(figsize=(12, 7))
    bars = ax.bar(workers_list, means, yerr=stds, capsize=10, 
                  alpha=0.8, color=plt.cm.viridis(np.linspace(0, 0.8, len(workers_list))))
    
    ax.set_xlabel('QUILL_WORKERS (Set via environment variable)', fontsize=12)
    ax.set_ylabel('Mean Execution Time (seconds)', fontsize=12)
    ax.set_title(f'Quill Runtime Performance: N-Queens ({config.BOARD_SIZE})\n'
                 f'Command: QUILL_WORKERS=X ./a.out {config.BOARD_SIZE}', 
                 fontsize=14, fontweight='bold')
    ax.grid(True, alpha=0.3, axis='y')
    
    # Add exact values on bars
    for x, mean, std in zip(workers_list, means, stds):
        ax.text(x, mean + std + 0.02, f'{mean:.3f}s\n±{std:.3f}', 
                ha='center', va='bottom', fontsize=10)
    
    plt.tight_layout()
    filename = f"{config.OUTPUT_DIR}/simple_bar_chart.{config.PLOT_FORMAT}"
    plt.savefig(filename, dpi=300, bbox_inches='tight')
    plt.close()
    
    return filename

def create_trend_plot(results: Dict[int, Dict], config: Config) -> str:
    """Create a trend plot showing all runs"""
    if not results:
        return ""
    
    fig, ax = plt.subplots(figsize=(12, 7))
    
    workers_list = sorted(results.keys())
    colors = plt.cm.Set2(np.linspace(0, 1, len(workers_list)))
    
    for idx, workers in enumerate(workers_list):
        times = results[workers]['times']
        x_positions = np.full(len(times), workers) + np.random.normal(0, 0.05, len(times))
        ax.scatter(x_positions, times, alpha=0.6, color=colors[idx], 
                  label=f'Workers={workers}', s=50)
        
        # Add mean line
        mean_val = results[workers]['stats']['mean']
        ax.hlines(y=mean_val, xmin=workers-0.3, xmax=workers+0.3, 
                 color='red', linewidth=2, alpha=0.8, linestyle='--')
        ax.text(workers, mean_val + 0.02, f'{mean_val:.3f}s', 
                ha='center', va='bottom', fontsize=10, color='red')
    
    ax.set_xlabel('QUILL_WORKERS', fontsize=12)
    ax.set_ylabel('Execution Time (seconds)', fontsize=12)
    ax.set_title(f'All Execution Times Distribution\nN-Queens ({config.BOARD_SIZE})', 
                 fontsize=14, fontweight='bold')
    ax.legend(title='Worker Count')
    ax.grid(True, alpha=0.3)
    ax.set_xticks(workers_list)
    
    plt.tight_layout()
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{config.OUTPUT_DIR}/trend_plot_{timestamp}.{config.PLOT_FORMAT}"
    plt.savefig(filename, dpi=300, bbox_inches='tight')
    plt.close()
    
    return filename

def plot_results(results: Dict[int, Dict], config: Config) -> List[str]:
    """Create all separate plots"""
    
    if not results:
        print("No results to plot!")
        return []
    
    # Set style
    plt.style.use('default')
    sns.set_palette("husl")
    
    print(f"\n📈 Generating separate plots...")
    
    plot_files = []
    
    # Generate each plot separately
    try:
        # 1. Performance plot
        print("  Creating performance plot...")
        perf_file = create_performance_plot(results, config)
        if perf_file:
            plot_files.append(perf_file)
            print(f"    ✓ Saved: {perf_file}")
        
        # 2. Speedup plot
        print("  Creating speedup plot...")
        speedup_file = create_speedup_plot(results, config)
        if speedup_file:
            plot_files.append(speedup_file)
            print(f"    ✓ Saved: {speedup_file}")
        
        # 3. Distribution plot
        print("  Creating distribution plot...")
        dist_file = create_distribution_plot(results, config)
        if dist_file:
            plot_files.append(dist_file)
            print(f"    ✓ Saved: {dist_file}")
        
        # 4. Efficiency plot
        print("  Creating efficiency plot...")
        eff_file = create_efficiency_plot(results, config)
        if eff_file:
            plot_files.append(eff_file)
            print(f"    ✓ Saved: {eff_file}")
        
        # 5. Simple bar chart
        print("  Creating simple bar chart...")
        simple_file = create_simple_bar_chart(results, config)
        if simple_file:
            plot_files.append(simple_file)
            print(f"    ✓ Saved: {simple_file}")
        
        # 6. Trend plot
        print("  Creating trend plot...")
        trend_file = create_trend_plot(results, config)
        if trend_file:
            plot_files.append(trend_file)
            print(f"    ✓ Saved: {trend_file}")
        
    except Exception as e:
        print(f"Error creating plots: {e}")
    
    print(f"\n✅ Generated {len(plot_files)} separate plots")
    
    # Optionally display the plots
    if config.VERBOSE and plot_files:
        print("\n🖼️  Displaying plots (close each to continue)...")
        for plot_file in plot_files:
            try:
                img = plt.imread(plot_file)
                fig, ax = plt.subplots(figsize=(10, 6))
                ax.imshow(img)
                ax.axis('off')
                ax.set_title(os.path.basename(plot_file))
                plt.show()
            except Exception as e:
                print(f"Could not display {plot_file}: {e}")
    
    return plot_files

# ===================== REPORT GENERATION =====================
def generate_report(results: Dict[int, Dict], config: Config) -> None:
    """Generate detailed report with statistics"""
    
    if not results:
        print("No results to report!")
        return
    
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    report_filename = f"{config.OUTPUT_DIR}/benchmark_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    
    with open(report_filename, 'w') as f:
        f.write("=" * 70 + "\n")
        f.write("QUILL RUNTIME BENCHMARK REPORT (Environment Variable)\n")
        f.write("=" * 70 + "\n\n")
        
        f.write(f"Benchmark Date: {timestamp}\n")
        f.write(f"Board Size: {config.BOARD_SIZE}\n")
        f.write(f"Runs per configuration: {config.RUNS_PER_WORKER}\n")
        f.write(f"Compilation command: {config.COMPILE_CMD}\n")
        f.write(f"Execution format: QUILL_WORKERS=X ./a.out {config.BOARD_SIZE}\n\n")
        
        f.write("-" * 70 + "\n")
        f.write("DETAILED RESULTS\n")
        f.write("-" * 70 + "\n\n")
        
        # Table header
        f.write(f"{'Workers':<10} {'Mean(s)':<12} {'StdDev':<12} {'Min':<12} "
                f"{'Max':<12} {'Success%':<12} {'CV%':<10}\n")
        f.write("-" * 80 + "\n")
        
        # Table rows
        for workers in sorted(results.keys()):
            stats = results[workers]['stats']
            f.write(f"{workers:<10} {stats['mean']:<12.4f} {stats['std']:<12.4f} "
                   f"{stats['min']:<12.4f} {stats['max']:<12.4f} "
                   f"{stats['success_rate']:<12.1f} {stats['cv']:<10.1f}\n")
        
        f.write("\n" + "-" * 70 + "\n")
        f.write("PERFORMANCE ANALYSIS\n")
        f.write("-" * 70 + "\n\n")
        
        # Calculate speedups if 1 worker exists
        if 1 in results:
            baseline = results[1]['stats']['mean']
            f.write(f"Baseline (QUILL_WORKERS=1): {baseline:.4f} seconds\n\n")
            
            f.write("Speedup Analysis:\n")
            f.write(f"{'Workers':<10} {'Mean Time':<12} {'Speedup':<12} {'Efficiency':<12}\n")
            f.write("-" * 46 + "\n")
            
            for workers in sorted(results.keys()):
                if workers == 1:
                    continue
                mean_time = results[workers]['stats']['mean']
                speedup = baseline / mean_time
                efficiency = (speedup / workers) * 100
                
                f.write(f"{workers:<10} {mean_time:<12.4f} {speedup:<12.2f} "
                       f"{efficiency:<12.1f}%\n")
        
        f.write("\n" + "-" * 70 + "\n")
        f.write("RECOMMENDATIONS\n")
        f.write("-" * 70 + "\n\n")
        
        # Find optimal worker count
        best_workers = min(results.keys(), key=lambda w: results[w]['stats']['mean'])
        best_time = results[best_workers]['stats']['mean']
        
        f.write(f"Optimal worker count: QUILL_WORKERS={best_workers}\n")
        f.write(f"Best execution time: {best_time:.4f} seconds\n\n")
        
        # Stability analysis
        most_stable = min(results.keys(), 
                         key=lambda w: results[w]['stats']['cv'])
        f.write(f"Most stable configuration: QUILL_WORKERS={most_stable} "
               f"(Coefficient of Variation={results[most_stable]['stats']['cv']:.1f}%)\n")
        
        f.write("\n" + "=" * 70 + "\n")
        f.write("EXECUTION COMMANDS USED\n")
        f.write("=" * 70 + "\n\n")
        
        for workers in sorted(results.keys()):
            f.write(f"QUILL_WORKERS={workers} ./a.out {config.BOARD_SIZE}\n")
        
        f.write("\n" + "=" * 70 + "\n")
        f.write("END OF REPORT\n")
        f.write("=" * 70 + "\n")
    
    print(f"\n📄 Detailed report saved to: {report_filename}")
    
    # Save as JSON
    json_filename = f"{config.OUTPUT_DIR}/benchmark_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    with open(json_filename, 'w') as f:
        json.dump({
            'config': {
                'workers_range': list(config.WORKERS_RANGE),
                'runs_per_worker': config.RUNS_PER_WORKER,
                'board_size': config.BOARD_SIZE,
                'execution_format': f"QUILL_WORKERS=X ./a.out {config.BOARD_SIZE}"
            },
            'results': {
                str(w): {
                    'times': results[w]['times'],
                    'stats': results[w]['stats']
                } for w in results
            }
        }, f, indent=2)
    
    print(f"📁 Raw data saved to: {json_filename}")

# ===================== MAIN FUNCTION =====================
def main():
    """Main entry point"""
    
    parser = argparse.ArgumentParser(
        description='Benchmark Quill runtime with QUILL_WORKERS environment variable'
    )
    parser.add_argument('--board-size', type=int, default=12,
                       help='N-Queens board size (default: 12)')
    parser.add_argument('--min-workers', type=int, default=1,
                       help='Minimum QUILL_WORKERS value (default: 1)')
    parser.add_argument('--max-workers', type=int, default=5,
                       help='Maximum QUILL_WORKERS value (default: 5)')
    parser.add_argument('--runs', type=int, default=10,
                       help='Number of runs per worker count (default: 10)')
    parser.add_argument('--output-dir', type=str, default='benchmark_results',
                       help='Output directory for results')
    parser.add_argument('--verbose', action='store_true',
                       help='Enable verbose output')
    parser.add_argument('--print-cmds', action='store_true', default=True,
                       help='Print exact commands being executed (default: True)')
    parser.add_argument('--skip-plot', action='store_true',
                       help='Skip plotting')
    
    args = parser.parse_args()
    
    # Update configuration
    Config.BOARD_SIZE = args.board_size
    Config.WORKERS_RANGE = (args.min_workers, args.max_workers)
    Config.RUNS_PER_WORKER = args.runs
    Config.OUTPUT_DIR = args.output_dir
    Config.VERBOSE = args.verbose
    Config.PRINT_COMMANDS = args.print_cmds
    
    print("\n" + "="*70)
    print("QUILL RUNTIME BENCHMARK SCRIPT (Environment Variable)")
    print("="*70)
    print("Using: QUILL_WORKERS=X ./a.out [board_size]")
    print("="*70)
    
    # Check if source files exist
    if not os.path.exists("./tests/nqueens.cpp"):
        print("❌ Error: nqueens.cpp not found!")
        sys.exit(1)
    
    # Find quill source file
    quill_files = [f for f in os.listdir('./src') if 'quill' in f and f.endswith('.cpp')]
    if not quill_files:
        print("❌ Error: No quill*.cpp file found!")
        sys.exit(1)
    
    print(f"\n📁 Found source files:")
    print(f"  - nqueens.cpp")
    for f in quill_files:
        print(f"  - {f}")
    
    print(f"\n🚀 Starting benchmark...")
    print(f"  Board size: {Config.BOARD_SIZE}")
    print(f"  Worker range: QUILL_WORKERS={Config.WORKERS_RANGE[0]}-{Config.WORKERS_RANGE[1]}")
    print(f"  Runs per worker: {Config.RUNS_PER_WORKER}")
    print(f"  Command format: QUILL_WORKERS=X ./a.out {Config.BOARD_SIZE}")
    
    # Quick test to see if environment variable works
    print(f"\n🔧 Testing environment variable...")
    test_cmd = f"QUILL_WORKERS=2 {Config.EXECUTABLE} {Config.BOARD_SIZE}"
    print(f"  Test command: {test_cmd}")
    
    start_time = time.time()
    results = run_benchmark(Config)
    benchmark_time = time.time() - start_time
    
    print(f"\n✅ Benchmark completed in {benchmark_time:.2f} seconds")
    
    if results:
        # Generate report
        generate_report(results, Config)
        
        # Plot results
        if not args.skip_plot:
            plot_files = plot_results(results, Config)
            
            # List all generated plots
            if plot_files:
                print("\n" + "="*70)
                print("📊 GENERATED PLOTS")
                print("="*70)
                for plot_file in plot_files:
                    print(f"  • {os.path.basename(plot_file)}")
        
        # Summary
        print("\n" + "="*70)
        print("📊 SUMMARY")
        print("="*70)
        
        for workers in sorted(results.keys()):
            stats = results[workers]['stats']
            print(f"\nQUILL_WORKERS={workers}:")
            print(f"  Mean: {stats['mean']:.4f}s ± {stats['std']:.4f}s")
            print(f"  Range: {stats['min']:.4f}s - {stats['max']:.4f}s")
            print(f"  Success rate: {stats['success_rate']:.1f}%")
        
        # Find best configuration
        if results:
            best = min(results.keys(), key=lambda w: results[w]['stats']['mean'])
            print(f"\n🏆 Best configuration: QUILL_WORKERS={best}")
            print(f"   Best mean time: {results[best]['stats']['mean']:.4f}s")
            
            # Calculate speedup
            if 1 in results:
                baseline = results[1]['stats']['mean']
                best_time = results[best]['stats']['mean']
                speedup = baseline / best_time
                print(f"   Speedup vs 1 worker: {speedup:.2f}x")
    else:
        print("\n❌ No valid results collected!")
    
    print("\n🎯 Done!")

if __name__ == "__main__":
    main()
