#pragma once
#ifndef QUILL_RUNTIME_H
#define QUILL_RUNTIME_H

#include <functional>
#include <pthread.h>
#include <ctime>
#include <algorithm>
#include "quill.h"

#define DEQUEUE_SIZE 1024

extern int QUILL_WORKERS;

typedef struct QuillThread {
    pthread_t _tid;
    std::function<void()>* _deque[DEQUEUE_SIZE];
    volatile int _head, _tail, _size, _mxsize, _taskstolen, _taskcompleted, _taskcreated;
    pthread_mutex_t _lock;

    QuillThread();

    int push_task_to_deque(std::function<void()> *task_ptr);

    int pop_task_from_deque(std::function<void()>*& task_ret);

    int steal_task_from_deque(std::function<void()>*& task_ret);

    void print_stats();
} QuillThread;

typedef struct FinishScope {
    volatile int _ntasks;
    pthread_mutex_t _finish_lock;

    FinishScope();

    FinishScope(int ntasks);

    void increment_task_counter();

    void decrement_task_counter();

    int get_finish_ntasks();
} FinishScope;

void* thread_runtime(void*);

typedef struct RuntimeManager {
    pthread_key_t thread_id_key;
    volatile bool shutdown;

    FinishScope finishscope;
    QuillThread* threadpool;
    long* thread_ix_ptr;

    RuntimeManager(int workers);
    ~RuntimeManager();

    void initialize_threadpool();

    void join_theadpool();

    void initial_finish_scope();

    long generate_victim_tid();
} RuntimeManager;

extern RuntimeManager* quill_runtime;

void find_task_and_execute();

void quill::init_runtime();

void quill::finalize_runtime();

void quill::start_finish();

void quill::end_finish();

void quill::async(std::function<void()>&& lambda);

#endif // QUILL_RUNTIME_H

