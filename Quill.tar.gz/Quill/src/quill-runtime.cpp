#include "quill-runtime.h"
#include "quill.h"
#include <cstdlib> 
#include <print>

int QUILL_WORKERS = 1; 
RuntimeManager* quill_runtime = nullptr;


QuillThread::QuillThread()
    : _head(0), _tail(0), _size(0), _mxsize(0), _taskstolen(0),
      _taskcompleted(0), _taskcreated(0), _lock(PTHREAD_MUTEX_INITIALIZER) {}

int QuillThread::push_task_to_deque(std::function<void()>* task_ptr) {
    int ret = 1;
    if ((_tail - 1 + DEQUEUE_SIZE) % DEQUEUE_SIZE != _head) {
        _size = _size + 1;
        _taskcreated = _taskcreated + 1;
        _mxsize = std::max(_mxsize, _size);
        ret = 0;
        _deque[(_tail - 1 + DEQUEUE_SIZE) % DEQUEUE_SIZE] = task_ptr;
        _tail = (_tail - 1 + DEQUEUE_SIZE) % DEQUEUE_SIZE;
    }
    return ret;
}

int QuillThread::pop_task_from_deque(std::function<void()>*& task_ret) {
    int ret = 1;
    pthread_mutex_lock(&_lock);
    if (_tail != _head) {
        _size = _size - 1;
        _taskcompleted = _taskcompleted + 1;
        ret = 0;
        task_ret = _deque[_tail];
        _tail = (_tail + 1) % DEQUEUE_SIZE;
    }
    pthread_mutex_unlock(&_lock);
    return ret;
}

int QuillThread::steal_task_from_deque(std::function<void()>*& task_ret) {
    int ret = 1;
    pthread_mutex_lock(&_lock);
    if (_tail != _head) {
        _size = _size - 1;
        _taskstolen = _taskstolen + 1;
        ret = 0;
        task_ret = _deque[(_head - 1 + DEQUEUE_SIZE) % DEQUEUE_SIZE];
        _head = (_head - 1 + DEQUEUE_SIZE) % DEQUEUE_SIZE;
    }
    pthread_mutex_unlock(&_lock);
    return ret;
}

void QuillThread::print_stats() {
    std::println("Greatest Queue Size ==> {}", (int)_mxsize);
    std::println("Task Created ==> {}", (int)_taskcreated);
    std::println("Task Stolen ==> {}", (int)_taskstolen);
    std::println("Task Completed ==> {}", (int)_taskcompleted);
}

FinishScope::FinishScope() : _ntasks(0), _finish_lock(PTHREAD_MUTEX_INITIALIZER) {}

FinishScope::FinishScope(int ntasks) : _ntasks(ntasks), _finish_lock(PTHREAD_MUTEX_INITIALIZER) {}

void FinishScope::increment_task_counter() {
    pthread_mutex_lock(&_finish_lock);
    _ntasks = _ntasks + 1;
    pthread_mutex_unlock(&_finish_lock);
}

void FinishScope::decrement_task_counter() {
    pthread_mutex_lock(&_finish_lock);
    _ntasks = _ntasks - 1;
    pthread_mutex_unlock(&_finish_lock);
}

int FinishScope::get_finish_ntasks() {
    return _ntasks;
}

RuntimeManager::RuntimeManager(int workers)
    : shutdown(false), threadpool(new QuillThread[workers]), thread_ix_ptr(new long[workers]) {
    for (int ix = 0; ix < workers; ix++) {
        thread_ix_ptr[ix] = ix;
    }
}

RuntimeManager::~RuntimeManager() {
    delete[] threadpool;
    delete[] thread_ix_ptr;
}

void RuntimeManager::initialize_threadpool() {
    pthread_key_create(&thread_id_key, NULL);
    pthread_setspecific(thread_id_key, (void*)thread_ix_ptr);
    for (long ithread = 1; ithread < QUILL_WORKERS; ithread++) {
        threadpool[ithread] = QuillThread();
        int ret = pthread_create(
            &threadpool[ithread]._tid,
            NULL,
            thread_runtime,
            (void*)(thread_ix_ptr + ithread)
        );

        if (ret) {
            std::println("Error encountered while thread creation");
            exit(1);
        }
    }
}

void RuntimeManager::join_theadpool() {
    for (int ithread = 1; ithread < QUILL_WORKERS; ithread++) {
        pthread_join(threadpool[ithread]._tid, NULL);
    }
}

void RuntimeManager::initial_finish_scope() {
    finishscope = FinishScope();
}

long RuntimeManager::generate_victim_tid() {
    return (long)(rand() % QUILL_WORKERS);
}

// Thread runtime function for executing tasks
void find_task_and_execute() {
    std::function<void()>* task_ptr = nullptr;
    long thread_ix = *((long*)pthread_getspecific(quill_runtime->thread_id_key));
    int retval = quill_runtime->threadpool[thread_ix].pop_task_from_deque(task_ptr);
    while (retval && quill_runtime->finishscope.get_finish_ntasks() > 0 && !quill_runtime->shutdown) {
        long victim_ix = quill_runtime->generate_victim_tid();
        if (victim_ix != thread_ix) {
            retval = quill_runtime->threadpool[victim_ix].steal_task_from_deque(task_ptr);
        }
    }
    if (retval) return;
    (*task_ptr)();
    quill_runtime->finishscope.decrement_task_counter();
    delete task_ptr;
}

void* thread_runtime(void* args) {
    pthread_setspecific(quill_runtime->thread_id_key, args);
    while (!quill_runtime->shutdown) {
        find_task_and_execute();
    }
    return NULL;
}

namespace quill {
    void init_runtime() {
        srand(time(NULL));
        const char* workers_env = getenv("QUILL_WORKERS");
        if (workers_env != nullptr) {
            QUILL_WORKERS = atoi(workers_env);
        }
        quill_runtime = new RuntimeManager(QUILL_WORKERS);
        quill_runtime->initialize_threadpool();
    }

    void finalize_runtime() {
        quill_runtime->shutdown = true;
        quill_runtime->join_theadpool();
#ifdef QUILL_DEBUG
        for (int ithread = 0; ithread < QUILL_WORKERS; ithread++) {
            std::println("===============================================");
            std::println("Runtime stats for thread no: {}", ithread);
            std::println("-----------------------------------------------");
            quill_runtime->threadpool[ithread].print_stats();
            std::println("===============================================\n");
        }
#endif
        pthread_key_delete(quill_runtime->thread_id_key);
        delete quill_runtime;
        quill_runtime = nullptr;
    }

    void start_finish() {
        quill_runtime->initial_finish_scope();
    }

    void end_finish() {
        while (quill_runtime->finishscope.get_finish_ntasks() > 0) {
            find_task_and_execute();
        }
    }

    void async(std::function<void()>&& lambda) {
        quill_runtime->finishscope.increment_task_counter();
        std::function<void()>* task_ptr = new std::function<void()>(lambda);
        long thread_ix = *((long*)pthread_getspecific(quill_runtime->thread_id_key));
        int ret = quill_runtime->threadpool[thread_ix].push_task_to_deque(task_ptr);
        if (ret != 0) {
            std::println("Deque for thread number :{}, overflow!!", thread_ix);
            exit(1);
        }
    }
}

